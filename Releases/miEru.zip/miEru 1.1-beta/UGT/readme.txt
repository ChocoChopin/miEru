Universal Game Translator

It's a pretty jank translation utility designed to work in two modes:

Desktop mode - Useful for games running in windows, webpages, or pictures

Camera mode - Snaps pictures from an HDMI input.  Tested with
Elgato Game Capture and Elgato Cam-Link.  Camera mode is designed
to be controlled with a 360 controller.  B button to initiate a snap/translate, after
that you can use the left joystick to navigate over the settings icon in the bottom
right to get some help.

Before using this, you need to setup your Google account.  Edit the file config_template.txt 
for more directions.  (You'll need to rename it config.txt as well)

For more info and help, visit the blog post about this:

https://www.codedojo.com/?p=2426

Seth A. Robinson
www.rtsoft.com