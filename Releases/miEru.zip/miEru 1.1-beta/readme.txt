// miEru //

Quick setup guide--full documentation available at https://github.com/ChocoChopin/miEru

miEru uses Google's Vision API to scan the text of your game's window, and then sends the result to the Windows clipboard, where it can be analyzed using browser extensions.

1. Extract **miEru.zip** anywhere you'd like

2. Install the browser addons [rikaikun](https://chrome.google.com/webstore/detail/rikaikun/jipdnfibhldikgcjhfnomkfpcebammhp?hl=en) (or [Rikaichamp for Firefox](https://addons.mozilla.org/en-US/firefox/addon/rikaichamp/)), [Clipboard Inserter](https://chrome.google.com/webstore/detail/clipboard-inserter/deahejllghicakhplliloeheabddjajm?hl=en) (or [for Firefox](https://addons.mozilla.org/en-US/firefox/addon/clipboard-inserter/)), and [Open-as-Popup](https://chrome.google.com/webstore/detail/open-as-popup/ncppfjladdkdaemaghochfikpmghbcpc?hl=en) (or [Popup window for Firefox](https://addons.mozilla.org/en-US/firefox/addon/popup-window/))

3. Navigate to **/miEru/CSS Files/** and open one of the provided HTML files by dragging and dropping it into your browser window

4. Toggle the dictionary and clipboard extensions on so that they look like [this](https://prnt.sc/tofam6); press the Open-as-Popup extension button to get rid of the window frame if you want

5. Run **miEru.exe**; you'll see its **見** taskbar icon appear

6. Select the window of whatever you want to capture, and press **Ctrl + F12**; captured text appears at the top of the browser window